<?php

    require "header.php";
    session_destroy();

?>
<link rel="Stylesheet" href="Style-login.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Navigation Bar Starts From Here -->

<div class="menu-bar">

<ul class="nav nav-tabs justify-content-center">

    <li class="nav-item">
        <a class="nav-link" href="index.php">Browse Jobs</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="foremployers.php">For Employers</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="companies.php">Companies</a>
    </li>
    <li class="nav-item">
         <a class="nav-link " href="signin.php">Sign in</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="howitworks.php">How it Works</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="help.php">Help</a>
     </li>
</ul>

</div>

<!-- Navigation Bar Ends -->

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Login Form -->
    <form method="post" action="login-code.php">
    <br>
    <div class="btn-group">
        <a href="#" class="btn btn-outline-primary active" aria-current="page">I'm a Employee</a>
        <a href="login-company.php" class="btn btn-outline-primary">I'm a Employer</a>
    </div>
      <input type="text" id="login" class="fadeIn second" name="username" placeholder="User E-mail">
      <input type="text" id="password" class="fadeIn third" name="pass" placeholder="password">
      <input type="submit" name="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
    </div>

  </div>
</div>

</body>
</html>