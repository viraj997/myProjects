<?php

    require "header.php";

?>

<!-- Navigation Bar Starts From Here -->

<div class="menu-bar">

<ul class="nav nav-tabs justify-content-center">

    <li class="nav-item">
        <a class="nav-link" href="index.php">Browse Jobs</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="foremployers.php">For Employers</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="companies.php">Companies</a>
    </li>
    <li class="nav-item">
         <a class="nav-link " href="signin.php">Sign in</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="howitworks.php">How it Works</a>
    </li>
    <li class="nav-item">
         <a class="nav-link active" href="help.php">Help</a>
     </li>
</ul>

</div>

<!-- Navigation Bar Ends -->
<br>
<div class="d-sm-flex align-items-center justify-content-center mb-4">
                        <h1 class="h3 mb-0 text-gray-900">Send an Inquiry</h1>
</div>

<div class="d-sm-flex align-items-center justify-content-center mb-3">
<div class="card shadow mb-4">
  <div class="card-header">

<form action="help-code.php" method="POST">

  <div class="form-group">
    <label>Your Email</label>
    <input type="text" name="email" class="form-control" maxlength="40" required>
  </div>

  <div class="form-group">
  <label>Message</label>
    <input type="text" name="content" class="form-control" required>
  </div>

  <button type="submit" name ="submit" class="btn btn-primary">Submit</button>
</form>

   </div>
</div>
</div>


<?php

    require "footer.php";

?>