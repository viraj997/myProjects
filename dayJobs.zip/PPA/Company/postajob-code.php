<?php

session_start();
include ("Database/dbconfig.php");

if(isset($_POST['submit']))
{

    $jobtype = $_POST['jobtype'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $payment = $_POST['payment'];
    $reqgender = $_POST['gender'];
    $reqpeople = $_POST['peoples'];
    $des = $_POST['des'];

    $sql = " INSERT INTO `post_job` 
    (`job_type`, `date`, `time`, `payment`, `req_gender`, `req_people`, `description`, `posted_by`) 
    VALUES ('".$jobtype."', '".$date."', '".$time."', '".$payment."', '".$reqgender."', '".$reqpeople."', '".$des."', '".$_SESSION['companyname']."'); ";  
    $query = mysqli_query($connection ,$sql);

    header('Location: postajob.php');

}

?>