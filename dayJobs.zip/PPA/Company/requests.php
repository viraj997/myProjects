<?php

    require "header.php";
    include ("Database/dbconfig.php");

?>

<!-- Navigation Bar Starts From Here -->

<div class="menu-bar">

<ul class="nav nav-tabs justify-content-center">

    <li class="nav-item">
        <a class="nav-link" href="postajob.php">Post A Job</a>
    </li>
    <li class="nav-item">
         <a class="nav-link active" href="requests.php">Requests</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="reviews.php">Reviews</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="employees.php">Employees</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="profile.php">Profile</a>
    </li>
</ul>

</div>

<!-- Navigation Bar Ends -->

<!-- Begin Page Content -->
<div class="container-fluid">
<br>
<div class="d-sm-flex align-items-center justify-content-center mb-4">
                        <h1 class="h3 mb-0 text-gray-900">Day Jobs</h1>
</div>
<!-- DataTales Example -->
<div class="card shadow mb-4" style="width: 100%">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Request details</h6>
    </div>
    <div class="card-body" >
        <div class="table-responsive">

        <?php

        $query = "SELECT * FROM `req_jobs` WHERE `company`='".$_SESSION['companyname']."' ORDER BY `req_time` DESC";
        $query_run = mysqli_query($connection,$query);

        ?>

            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Job ID</th>
                        <th>Employee name</th>
                        <th>Employee email</th>
                        <th>Requested time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    if(mysqli_num_rows($query_run)>0)
                    {
                        while($row = mysqli_fetch_assoc($query_run))
                        {
                    ?>

                    <tr>
                        <td><?php echo $row['jobid']; ?></td>
                        <td><?php echo $row['emp_name']; ?></td>
                        <td><?php echo $row['emp_email']; ?></td>
                        <td><?php echo $row['req_time']; ?></td>

                        <td>
                        <div class="modal-footer">
                            <button type="submit" name="submit" class="btn btn-primary" data-dismiss="modal">Accept</button>
                        </div>
                        </td>
                        
                    </tr>

                    <?php

                        }

                    }else {

                        echo 'No records found';
                    }

                    ?>

                   
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

<?php

    require "footer.php";

?>