<div class="fixed-bottom" >
    <div id="copyright">
    	<p> Copyright &copy; 2021 DayJobs | All rights reserved | DATA SQUAD </p>
    </div>
</div>


</body>
</html>