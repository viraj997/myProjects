<?php

    require "header.php";

?>

<!-- Navigation Bar Starts From Here -->

<div class="menu-bar">

<ul class="nav nav-tabs justify-content-center">

    <li class="nav-item">
        <a class="nav-link active" href="postajob.php">Post A Job</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="requests.php">Requests</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="reviews.php">Reviews</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="employees.php">Employees</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="profile.php">Profile</a>
    </li>
</ul>

</div>

<!-- Navigation Bar Ends -->
<br>
<div class="d-sm-flex align-items-center justify-content-center mb-4">
                        <h1 class="h3 mb-0 text-gray-900">Post A New Job</h1>
</div>

<div class="d-sm-flex align-items-center justify-content-center mb-3">
<div class="card shadow mb-4">
  <div class="card-header">

<form action="postajob-code.php" method="POST">

  <div class="form-group">
    <label>Job Type</label>
    <input type="text" name="jobtype" class="form-control" maxlength="40" required>
    <small id="first" style="color: red"></small>
  </div>

  <div class="form-group">
    <label>Date</label>
    <input type="text" name="date" class="form-control" maxlength="40" required>
    <small id="last" style="color: red"></small>
  </div>

  <div class="form-group">
    <label>Time</label>
    <input type="text" name="time" class="form-control" maxlength="40" required>
    <small id="last" style="color: red"></small>
  </div>

  <div class="form-group">
    <label>Payment</label>
    <input type="text" name="payment" class="form-control" maxlength="40" required>
    <small id="last" style="color: red"></small>
  </div>

  <div class="form-group">
    <label>reuired gender</label>
    <input type="text" name="gender" class="form-control checking_email" maxlength="100" required>
    <small id="email" style="color: red"></small>
  </div>

  <div class="form-group">
    <label>required peoples</label>
    <input type="text" name="peoples" class="form-control"  maxlength="10" required>
    <small id="contact" style="color: red"></small>
  </div>

  <div class="form-group">
    <label>description</label>
    <input type="text" name="des" class="form-control" maxlength="25" required>
    <small id="pwd" style="color: red"></small>
  </div>

  <button type="submit" name ="submit" class="btn btn-primary">Submit</button>
</form>

   </div>
</div>
</div>

<?php

    require "footer.php";

?>