<?php

include "includes/header.php";
include "includes/listaccounts-sidebar.php";
include "includes/navbar.php";

?>

<div class="d-sm-flex align-items-center justify-content-center mb-4">
                        <h1 class="h3 mb-0 text-gray-900">Admin Accounts</h1>
</div>

<!-- Begin Page Content -->
<div class="container-fluid">


<!-- DataTales Example -->
<div class="card shadow mb-4" style="width: 100%">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">All Registered admin account details</h6>
    </div>
    <div class="card-body" >
        <div class="table-responsive">

        <?php
        
        $connection = mysqli_connect("localhost" , "root" , "" , "ppaproject");
        $query = "SELECT * FROM `adminreg` ORDER BY `addeddate` DESC";
        $query_run = mysqli_query($connection,$query);

        ?>

            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>E-mail</th>
                        <th>Contact No</th>
                        <th>Added by</th>
                        <th>Added date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    if(mysqli_num_rows($query_run)>0)
                    {
                        while($row = mysqli_fetch_assoc($query_run))
                        {
                    ?>

                    <tr>
                        <td><?php echo $row['firstname']; ?></td>
                        <td><?php echo $row['lastname']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['contactno']; ?></td>
                        <td><?php echo $row['addedby']; ?></td>
                        <td><?php echo $row['addeddate']; ?></td>

                        <td>
                        <form action="edit_accounts.php" method="POST">

                        <input type="hidden" name="edit_id" value="<?php echo $row['email']; ?>">
                        <button type="submit" name="edit_btn" class="btn btn-outline-success btn-sm">Edit</button>

                        </form>
                        </td>
                        <td>
                            <form action="register-code.php" method="post">
                            
                            <input type="hidden" name="del_id" value="<?php echo $row['email']; ?>">
                            <button type="submit" name="deletebtn" class="btn btn-outline-danger btn-sm">Delete</button>

                            </form>
                        </td>
    
                    </tr>

                    <?php

                        }

                    }else {

                        echo 'No records found';
                    }

                    ?>

                   
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

<?php

include "includes/scripts.php";
include "includes/footer.php";

?> 
