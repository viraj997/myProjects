<?php

    require "header.php";

    include ("Database/dbconfig.php");


//Getting user's IP
//-------------------------------------------
$visitor_ip = $_SERVER['REMOTE_ADDR'];
//-------------------------------------------


//checking ip is already entered

$sql = " SELECT * FROM visit_count WHERE ip_address='$visitor_ip' ";
$result = mysqli_query($connection , $sql);

if(!$result)
{

    die("Retriving Query Error<br>".$query);

}

$total_visit = mysqli_num_rows($result);

if($total_visit<1)
{

    $sql = " INSERT INTO visit_count(ip_address) VALUES('".$visitor_ip."') ";
    $result = mysqli_query($connection , $sql);

}

?>

<!-- Navigation Bar Starts From Here -->

<div class="menu-bar">

<ul class="nav nav-tabs justify-content-center">

    <li class="nav-item">
        <a class="nav-link active" href="index.php">Browse Jobs</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="foremployers.php">For Employers</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="companies.php">Companies</a>
    </li>
    <li class="nav-item">
         <a class="nav-link " href="signin.php">Sign in</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="howitworks.php">How it Works</a>
    </li>
    <li class="nav-item">
         <a class="nav-link" href="help.php">Help</a>
     </li>
</ul>

</div>

<!-- Navigation Bar Ends -->

<!-- Begin Page Content -->
<div class="container-fluid">
<br>
<div class="d-sm-flex align-items-center justify-content-center mb-4">
                        <h1 class="h3 mb-0 text-gray-900">Day Jobs</h1>
</div>
<!-- DataTales Example -->
<div class="card shadow mb-4" style="width: 100%">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">All Posted Job details</h6>
    </div>
    <div class="card-body" >
        <div class="table-responsive">

        <?php

        $query = "SELECT * FROM `post_job` ORDER BY `time_stamp` DESC";
        $query_run = mysqli_query($connection,$query);

        ?>

            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Posted Date</th>
                        <th>Company Name</th>
                        <th>Job Type</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Payment</th>
                        <th>Required Gender</th>
                        <th>Required Peoples</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    if(mysqli_num_rows($query_run)>0)
                    {
                        while($row = mysqli_fetch_assoc($query_run))
                        {
                    ?>

                    <tr>
                        <td><?php echo $row['time_stamp']; ?></td>
                        <td><?php echo $row['posted_by']; ?></td>
                        <td><?php echo $row['job_type']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['date']; ?></td>
                        <td><?php echo $row['time']; ?></td>
                        <td><?php echo $row['payment']; ?></td>
                        <td><?php echo $row['req_gender']; ?></td>
                        <td><?php echo $row['req_people']; ?></td>

                        <td>
                        <form action="applyfor-job-code.php" method="POST">
                        <div class="modal-footer">
                            <input type="hidden" name="jobid" value="<?php echo $row['pid']; ?>">
                            <input type="hidden" name="company" value="<?php echo $row['posted_by']; ?>">
                            <button type="submit" name="submit" class="btn btn-primary" data-dismiss="modal">Apply</button>
                        </div>
                        </form>
                        </td>
                        
                    </tr>

                    <?php

                        }

                    }else {

                        echo 'No records found';
                    }

                    ?>

                   
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

<?php

    require "footer.php";

?>